package com.example.fitlife;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.List;

public class BackActivity extends AppCompatActivity {
    private ListView exerciseListView;
    private ImageView exerciseImageView;
    private Button backToMainButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_back);

        // Initialize Views
        exerciseListView = findViewById(R.id.exerciseListView);
        exerciseImageView = findViewById(R.id.exerciseImageView);
        backToMainButton = findViewById(R.id.backToMainButton);

        // Create a list of exercises
        List<Exercise> exercises = new ArrayList<>();
        exercises.add(new Exercise("V-Bar Pulldown", R.drawable.vbar));
        exercises.add(new Exercise("Barbell shrugs", R.drawable.bs));
        exercises.add(new Exercise("Bent Over Barbell Row", R.drawable.bent));
        exercises.add(new Exercise("Seated Cable Rows", R.drawable.scr));
        exercises.add(new Exercise("BB Upright Rows", R.drawable.bb));


        // Set adapter for the ListView
        ExerciseAdapter adapter = new ExerciseAdapter(this, exercises);
        exerciseListView.setAdapter(adapter);

        // Set item click listener for the ListView
        exerciseListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // Get the clicked exercise
                Exercise clickedExercise = exercises.get(position);
                // Update the ImageView with the  image
                exerciseImageView.setImageResource(clickedExercise.getImageResource());
            }
        });

        //  Back button click
        backToMainButton.setOnClickListener(v -> {
            // Go back to the MainActivity
            Intent intent = new Intent(BackActivity.this, MainActivity.class);
            startActivity(intent);
        });
    }
}