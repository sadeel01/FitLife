package com.example.fitlife;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.List;

public class LegsActivity extends AppCompatActivity {
    private ListView exerciseListView;
    private ImageView exerciseImageView;
    private Button backToMainButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_legs);

        // Initialize Views
        exerciseListView = findViewById(R.id.exerciseListView);
        exerciseImageView = findViewById(R.id.exerciseImageView);
        backToMainButton = findViewById(R.id.backToMainButton);

        // Create a list of exercises
        List<Exercise> exercises = new ArrayList<>();
        exercises.add(new Exercise("Squats", R.drawable.squat));
        exercises.add(new Exercise("Leg Press", R.drawable.lp));
        exercises.add(new Exercise("Leg Curls", R.drawable.lc));
        exercises.add(new Exercise("Calf Raises", R.drawable.cr));
        exercises.add(new Exercise("Seated Calf Raises", R.drawable.sc));


        // Set adapter for the ListView
        ExerciseAdapter adapter = new ExerciseAdapter(this, exercises);
        exerciseListView.setAdapter(adapter);

        // Set item click listener for the ListView
        exerciseListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // Get exercise
                Exercise clickedExercise = exercises.get(position);
                // Update the ImageView
                exerciseImageView.setImageResource(clickedExercise.getImageResource());
            }
        });


        backToMainButton.setOnClickListener(v -> {

            Intent intent = new Intent(LegsActivity.this, MainActivity.class);
            startActivity(intent);
        });
    }
}