package com.example.fitlife;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.List;

public class ChestActivity extends AppCompatActivity {

    private ListView exerciseListView;
    private ImageView exerciseImageView;
    private Button backToMainButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chest);

        // Initialize Views
        exerciseListView = findViewById(R.id.exerciseListView);
        exerciseImageView = findViewById(R.id.exerciseImageView);
        backToMainButton = findViewById(R.id.backToMainButton);

        // Create a list of exercises
        List<Exercise> exercises = new ArrayList<>();
        exercises.add(new Exercise("flat bb bench press", R.drawable.fbb));
        exercises.add(new Exercise("Incline bb press", R.drawable.ibb));
        exercises.add(new Exercise("Decline db press", R.drawable.ddb));
        exercises.add(new Exercise(" Fly cable crossover", R.drawable.fcc));


        // Set adapter for the ListView
        ExerciseAdapter adapter = new ExerciseAdapter(this, exercises);
        exerciseListView.setAdapter(adapter);

        // Set item click listener for the ListView
        exerciseListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // Get the clicked exercise
                Exercise clickedExercise = exercises.get(position);
                // Update the ImageView with the corresponding image
                exerciseImageView.setImageResource(clickedExercise.getImageResource());
            }
        });

        // Handle the "Back to Main" button click
        backToMainButton.setOnClickListener(v -> {
            // Go back to the MainActivity
            Intent intent = new Intent(ChestActivity.this, MainActivity.class);
            startActivity(intent);
        });
    }
}
